import * as React from 'react';
import { Text, View, StyleSheet, Button, TextInput } from 'react-native';
import { createMaterialBottomTabNavigator } from '@react-navigation/material-bottom-tabs';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { NavigationContainer } from '@react-navigation/native';
import Add_meeting from './screens/Add_Meeting';
import Upcoming_Meetings from './screens/Upcoming_Meetings';

const Tab = createMaterialBottomTabNavigator();
export default class Navigation extends React.Component {
  render() {
    return (
      <NavigationContainer style={styles.container}>
        <Tab.Navigator
          initialRouteName="Feed"
          activeColor="#e91e63"
          barStyle={{ backgroundColor: '#190c50' }}>
          <Tab.Screen
            name="Add_meeting"
            component={Add_meeting}
            options={{
              tabBarLabel: 'Add Meeting',
              tabBarIcon: ({ color }) => (
                <MaterialCommunityIcons name="plus" color={color} size={25} />
              ),
            }}
          />

          <Tab.Screen
            name="Notifications"
            component={Upcoming_Meetings}
            options={{
              tabBarLabel: 'Upcoming meetings',
              tabBarIcon: ({ color }) => (
                <MaterialCommunityIcons name="note" color={color} size={25} />
              ),
            }}
          />
        </Tab.Navigator>
      </NavigationContainer>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'white',
    padding: 8,
  },
});
