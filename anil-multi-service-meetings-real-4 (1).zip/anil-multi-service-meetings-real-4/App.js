import * as React  from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Add_Meeting from './screens/Add_Meeting'
import { createAppContainer , createSwitchNavigator } from "react-navigation"
import Navigation from './Navigation';
import Login from './screens/login'
import Home from './screens/Home'
import Upcoming_Meetings from './screens/Upcoming_Meetings'

const Nav = createSwitchNavigator({
  Login:Login,
  Navigation:Navigation,
  Home:Home,
});

const AppContainer = createAppContainer(Nav)

export default class App extends React.Component{
  render(){
  return (
    <View style={styles.container}>
      <AppContainer/>
    </View>
  );
}}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  
});
