import * as React from 'react';
import {
  Text,
  View,
  StyleSheet,
  Button,
  TextInput,
  Image,
  TouchableOpacity,
} from 'react-native';
import db from '../config';
import { collection } from 'firebase/firestore';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

export default class Home extends React.Component {
  render() {
    return (
      <View>
        <Text style={styles.text}>Anil Multi Service Meetings</Text>
        <Image
          style={styles.imageIcon}
          source={{
            uri: 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/5f3fe1dc44e313074ff89c5527a8bf50',
          }}
        />
        <TouchableOpacity
          style={styles.button}
          onPress={() => {
            this.props.navigation.navigate('Navigation');
          }}>
          <Text style={styles.paragraph}>Continue</Text>
        </TouchableOpacity>
        
        <Text style={styles.text2}>Made By Hardik Arora</Text>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  text: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  imageIcon: {
    width: 250,
    height: 220,
    alignSelf: 'center',
  
  },
  button: {
    backgroundColor: 'red',
    borderWidth: 2,
    borderRadius: 40,
    width: 200,
    height: 100,
    textAlign: 'center',
    alignSelf: 'center',
  },
  paragraph: {
    margin: 24,
    fontSize: 30,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  text2: {
    marginTop: 120,
    fontSize: 14,
    fontWeight: 'bold',
  },
  
});
