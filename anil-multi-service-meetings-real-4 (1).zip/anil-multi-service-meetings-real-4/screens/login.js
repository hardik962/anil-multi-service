import * as React from 'react';
import {
  Text,
  View,
  StyleSheet,
  Button,
  TouchableOpacity,
  TextInput,
  Image,
  Alert,
} from 'react-native';
import db from '../config';
import firebase from 'firebase';

export default class login extends React.Component {
  constructor() {
    super();
    this.state = {
      email: '',
      password: '',
    };
  }

  handleLogin = (e, p) => {
     firebase
      .auth()
      .signInWithEmailAndPassword(e,p)
      .then((r) => {
        this.props.navigation.navigate('Home')
      })
      .catch((error) => {
        Alert.alert(error.message);
      });
      
  };
  render() {
    return (
      <View>
        <Text
          style={{
            alignSelf: 'center',
            marginBottom: -20,
            fontSize: 30,
            fontWeight: 'bold',
            textAlign: 'center',
          }}>
          Anil Multi Service Meetings
        </Text>

        <Image
          style={styles.imageIcon}
          source={{
            uri: 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/5f3fe1dc44e313074ff89c5527a8bf50',
          }}
        />

        <TextInput
          style={styles.textinput}
          placeholder={'Enter Email Id'}
          onChangeText={(text) => this.setState({ email: text })}
        />
        <TextInput
          style={styles.textinput2}
          placeholder={'Enter Password'}
          secureTextEntry={true}
          onChangeText={(text) => this.setState({ password: text })}
        />
        <TouchableOpacity
          style={styles.button}
          onPress={() =>
            this.handleLogin(this.state.email, this.state.password)
          }>
          <Text> Login</Text>
        </TouchableOpacity>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  textinput: {
    marginTop: 1,
    width: '70%',
    alignSelf: 'center',
    height: 40,
    textAlign: 'center',
    backgroundColor: 'lightgrey',
    borderWidth: 4,
    outline: 'none',
    borderRadius: 30,
  },
  textinput2: {
    marginTop: 10,
    width: '70%',
    alignSelf: 'center',
    height: 40,
    textAlign: 'center',
    backgroundColor: 'lightgrey',
    borderWidth: 4,
    borderRadius: 30,
    outline: 'none',
  },
  button: {
    width: '30%',
    height: 55,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'yellow',
    borderRadius: 15,
    marginLeft: 100,
    marginTop: 20,
    marginLeft: 120,
    borderWidth: 2,
  },
  imageIcon: {
    width: 220,
    height: 220,
    alignSelf: 'center',
    marginTop: 0,
  },
});
/*
1. map in address
2. google authenciation
3. solving keypad problem
4. making app more good look
*/
